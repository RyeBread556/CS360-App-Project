package com.zybooks.eventtracker;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddEventActivity extends AppCompatActivity {

    EditText eventName;
    EditText eventDate;
    EditText eventTime;
    EditText eventDescription;
    Button saveEventButton;
    Button updateEventButton;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_event_activity);
        db = new DatabaseHelper(this);
        eventName = findViewById(R.id.eventName);
        eventDate = findViewById(R.id.eventDate);
        eventTime = findViewById(R.id.eventTime);
        eventDescription = findViewById(R.id.eventDescription);
        saveEventButton = findViewById(R.id.saveEventButton);
        updateEventButton = findViewById(R.id.updateEventButton);

        updateEventButton.setOnClickListener(view -> {
            int id = db.getLastEventId();
            if (id != -1) {
                db.updateEvent(id, eventName.getText().toString(), eventDate.getText().toString(), eventTime.getText().toString(), eventDescription.getText().toString());
                Toast.makeText(AddEventActivity.this, "Event updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(AddEventActivity.this, "Error updating event", Toast.LENGTH_SHORT).show();
            }
        });
        saveEventButton.setOnClickListener(view -> {
            boolean success = db.insertEvent(eventName.getText().toString(), eventDate.getText().toString(), eventTime.getText().toString(), eventDescription.getText().toString());
            if (success) {
                Toast.makeText(AddEventActivity.this, "Event added successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(AddEventActivity.this, "Error adding event", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
