package com.zybooks.eventtracker;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Button;
import android.widget.ListView;
import android.database.Cursor;
import android.widget.ArrayAdapter;
import java.util.ArrayList;

public class EventsActivity extends AppCompatActivity {
    Button addEventButton;
    Button deleteButton;
    Button notificationsButton;
    ListView eventsListView;
    DatabaseHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);
        db = new DatabaseHelper(this);
        eventsListView = findViewById(R.id.eventsListView);
        eventsListView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(EventsActivity.this, AddEventActivity.class);
            startActivity(intent);
        });


        notificationsButton = findViewById(R.id.notificationsButton);
        notificationsButton.setOnClickListener(view -> {
            Intent intent = new Intent(EventsActivity.this, NotificationsActivity.class);
            startActivity(intent);
        });
        addEventButton = findViewById(R.id.addEventButton);
        addEventButton.setOnClickListener(view -> {
            Intent intent = new Intent(EventsActivity.this, AddEventActivity.class);
            startActivity(intent);
        });
        deleteButton = findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener(view -> {
            db.deleteAllEvents();
            loadEvents();
        });

        loadEvents();
    }
    private void loadEvents() {
        ArrayList<String> eventList = new ArrayList<>();
        Cursor cursor = db.getAllEvents();
        while (cursor.moveToNext()) {
            String event = cursor.getString(1) + " _ " + cursor.getString(2);
            eventList.add(event);

        }
        cursor.close();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventList);
        eventsListView.setAdapter(adapter);
    }

}
